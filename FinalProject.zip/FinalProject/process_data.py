import pandas as pd
import matplotlib.pyplot as plt
from pymongo import MongoClient

# MongoDB connection
client = MongoClient("mongodb://localhost:27017/")
db = client.survey_data
collection = db.participants

# Fetch data from MongoDB
data = list(collection.find())

# Convert to DataFrame
df = pd.DataFrame(data)

# Ensure numeric conversions
df['age'] = pd.to_numeric(df['age'], errors='coerce')
df['total_income'] = pd.to_numeric(df['total_income'], errors='coerce')

# Normalize the 'expenses' field (nested dictionary)
if 'expenses' in df.columns:
    expenses = pd.json_normalize(df['expenses'])
    expenses = expenses.apply(pd.to_numeric, errors='coerce')  # Convert all columns to numeric
    expenses['gender'] = df['gender']  # Add gender for grouping
    df = pd.concat([df, expenses], axis=1)  # Merge expenses with main DataFrame
else:
    print("Error: 'expenses' field is missing or empty.")
    expenses = pd.DataFrame()  # Fallback if no expenses data

# Save data to CSV
csv_path = "survey_data.csv"
df.to_csv(csv_path, index=False)
print(f"Data saved to {csv_path}")

# Visualization 1: Ages with Highest Income
plt.figure(figsize=(10, 6))
plt.bar(df['age'], df['total_income'], color='skyblue')
plt.title('Ages with Highest Income')
plt.xlabel('Age')
plt.ylabel('Total Income')
plt.savefig("age_income_chart.png")
plt.close()
print("Saved age-income chart as 'age_income_chart.png'.")

# Visualization 2: Gender Spending Distribution
if not expenses.empty:
    grouped = expenses.groupby('gender').sum()

    if not grouped.empty:
        grouped.plot(kind='bar', stacked=True, figsize=(10, 6), colormap='viridis')
        plt.title('Gender Spending Distribution')
        plt.xlabel('Gender')
        plt.ylabel('Amount Spent')
        plt.savefig("gender_spending_chart.png")
        plt.close()
        print("Saved gender-spending chart as 'gender_spending_chart.png'.")
    else:
        print("No numeric data available for plotting gender spending distribution.")
else:
    print("Expenses data is empty. Skipping gender spending distribution chart.")
