from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient

# Initialize Flask app
app = Flask(__name__)

# MongoDB connection
client = MongoClient("mongodb://localhost:27017/")
db = client.survey_data  # Database name
collection = db.participants  # Collection name

@app.route('/', methods=['GET', 'POST'])
def form():
    if request.method == 'POST':
        # Collect form data
        age = request.form.get('age')
        gender = request.form.get('gender')
        total_income = request.form.get('total_income')
        expenses = {
            'utilities': request.form.get('utilities', 0),
            'entertainment': request.form.get('entertainment', 0),
            'school_fees': request.form.get('school_fees', 0),
            'shopping': request.form.get('shopping', 0),
            'healthcare': request.form.get('healthcare', 0)
        }
        # Prepare data for MongoDB
        data = {
            'age': age,
            'gender': gender,
            'total_income': total_income,
            'expenses': expenses
        }
        # Insert into MongoDB
        collection.insert_one(data)
        return redirect(url_for('thank_you'))
    return render_template('form.html')

@app.route('/thank-you')
def thank_you():
    return "Thank you for submitting your data!"

if __name__ == '__main__':
    app.run(debug=True)
